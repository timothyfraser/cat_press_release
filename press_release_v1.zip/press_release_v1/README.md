# README: `press_release`

- Notes by: Tim Fraser

To adapt this `press_release` report generator to use in a ShinyApp, I made 3 key changes.

1. Relative image paths (eg. the logo) were removed, because I couldn't figure it out.
2. Relative function paths (eg. `Graph`) were removed, and the functions were put directly in the report script, so that it runs properly.
3. `press_release` was added to the `.buildignore` file in the `/visualizer` folder.